package com.oms.order.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.order.service.OrderService;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(OrderController.REST)
public class OrderController {
	
	private static Logger logger = LoggerFactory.getLogger(OrderService.class);
	public static final String REST="/rest" ;
	
	@Autowired
	private OrderService orderService;

    // get Order details by communication product service using feign client
    @RequestMapping(value = "/order/{orderId}")
    public Map getCustomerById(@PathVariable("orderId") Integer orderId) {
    	logger.info("Get Order by Id : "+ orderId);
        return orderService.getOrderDetailsById(orderId);
    }

}
	


