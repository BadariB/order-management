package com.oms.order.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(name="product-service" )//Service Id of account service
public interface ProductServiceProxy {
	
	 @RequestMapping("/rest/product/{productCode}")
	 public List<Product> getProductByProductCode(@PathVariable("productCode") String productCode);

}
