package com.oms.order.service;

public class Order {

	private Integer orderId;

	private String productCode;

	private String orderDate;

	private String shippingAddress;

	private double total;

	public Order() {
	}

	public Order(Integer orderId, String productCode, String orderDate, String shippingAddress, Double total) {

		this.orderId = orderId;
		this.productCode = productCode;
		this.orderDate = orderDate;
		this.shippingAddress = shippingAddress;
		this.total = total;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

}
