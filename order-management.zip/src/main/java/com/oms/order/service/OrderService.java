package com.oms.order.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrderService {

	private static Logger logger = LoggerFactory.getLogger(OrderService.class);

	private List<Order> orders;

	@Autowired
	private ProductServiceProxy productServiceProxy;

	public OrderService() {
		orders = new ArrayList<>();
		orders.add(new Order(1, "NO123", "30/06/2020", "Hyderabad", 10000D));
		orders.add(new Order(2, "MI123", "30/06/2020", "Hyderabad", 10000D));
	}

	public List<Order> getOrders() {
		logger.info("Method getOrders() is called.");
		return orders;
	}

	public Map getOrderDetailsById(Integer orderId) {
		logger.info("Method getOrderDetailsById() is called.");
		logger.info("Get order by ID :" + orderId);
		Map<String, String> mapObj = new HashMap<String, String>();
		List<Order> ordersList = orders.stream().filter(o -> o.getOrderId().equals(orderId))
				.collect(Collectors.toList());
		List<Product> productList = null;
		if (!productList.isEmpty())
			productList = productServiceProxy.getProductByProductCode(ordersList.get(0).getProductCode());

		if (!ordersList.isEmpty()) {
			mapObj.put("Date", ordersList.get(0).getOrderDate());
			mapObj.put("ShippingAddress", ordersList.get(0).getShippingAddress());
			mapObj.put("ProductName", productList.get(0).getProductName());
			mapObj.put("TotalAmount", ordersList.get(0).getTotal() + "");

		}
		return mapObj;
	}
}
