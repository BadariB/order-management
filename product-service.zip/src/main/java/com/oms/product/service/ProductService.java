package com.oms.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class ProductService {
	
    private static Logger logger = LoggerFactory.getLogger(ProductService.class);
    
    private List<Product> products;
    
    // Hard coded values
    public ProductService() {
        products = new ArrayList<>();
        products.add(new Product("NO123","Nokia",1));
        products.add(new Product("MI123","MiNote4",2));
        products.add(new Product("MI124","MiNote2",1));
    }
  
    // get All products
    public List<Product> getProducts() {
    	logger.info("Method getProducts() is called.");
    	return products;
    }
    
   // get product by code 
   public List<Product> getProductByProductCode(Integer productCode) {
	   logger.info("Method getProductByProductId() is called.");
	   logger.info("Get product code :"+ productCode );
	   return products.stream().filter(o -> o.getProductCode().equals(productCode)).collect(Collectors.toList());
    }
   
 
}
	


