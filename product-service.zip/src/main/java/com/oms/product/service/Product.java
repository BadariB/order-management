package com.oms.product.service;

public class Product {

	private Integer pId;
	private String productCode;
	private String productName;
	private Integer quantity;

	public Product() {
	}

	public Product(String productCode, String productName, Integer quantity) {

		this.productCode = productCode;
		this.productName = productName;
		this.quantity = quantity;
	}

	public Integer getpId() {
		return pId;
	}

	public void setpId(Integer pId) {
		this.pId = pId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	
}
